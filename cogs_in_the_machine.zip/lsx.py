def c(mystr):
    return "flag{red_h3rring}"

# Look deep into the void.  The magic word is where I live.