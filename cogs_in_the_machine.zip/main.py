#####################################################
#                                                   #
#                 COGS IN THE MACHINE               #
#               Written by Jason Scott              #
#               jason.scott@mcpa-stl.org            #
#                                                   #
#                 HACK THE ARCH 2017                #
#                                                   #
#              Composed in Python 3.5               #
#                   PEP 8 Compliant                 #
#                                                   #
#####################################################

# IMPORTS
import tkinter as tk
import socket
import getpass as gp
import grh as h
import binascii as ba

# VARIABLES
prgmWidth = 550
prgmHeight = 480
states = [b'6e6f726d616c', b'7768697465', b'626c61636b', b'726564', b'79656c6c6f77', b'626c7565', b'656e61626c6564',
          b'74727565', b'66616c7365', b'64697361626c6564', b'6f6e', b'6f6666']
var_lst = [69, 82, 79]


# CLASSES
class prgm(tk.Tk):
    def __init__(self, parent):
        tk.Tk.__init__(self, parent)
        self.parent = parent
        self.initialize()
        self.lbl_code = None
        self.validate = tk.Entry(self.step_one, width=50)
        self.validate.grid(row=0, column=1, columnspan=3, pady=5, sticky='WE')
        self.validate.configure(state="{}".format(h.u(states[int(chr(57))])))
        self.code_val = None
        self.main_text = None
        self.sub_text = None
        self.lower_text = None
        self.detail_text = None
        self.header = None
        self.btn_ok = None
        self.step_one = None
        self.frame_header = None

    def initialize(self):
        self.tk.call('wm', 'iconphoto', self._w, tk.PhotoImage(file='img/icoMCPA.gif'))
        self.grid()
        self.step_one = tk.LabelFrame(self, text="", bg='#FFFFFF', width=500, relief="flat")
        self.step_one.grid(row=0, columnspan=7, sticky='W', padx=20, pady=5, ipadx=5, ipady=5)
        self.lbl_code = tk.Label(self.step_one, text="Magic Word:", justify="left", bg='#FFFFFF')
        self.lbl_code.grid(row=0, column=0, sticky='E', padx=5, pady=5)
        self.step_one.place(x=45, y=325)
        self.btn_ok = tk.Button(self.step_one, text='Submit', command=self.submit, width=20, bg='#003399', fg='#FFFFFF')
        self.btn_ok.grid(row=4, column=2, sticky='W', padx=5, pady=2)

    def submit(self):
        self.code_val = self.validate.get()
        if self.validate.get() == "":
            print(showmsg())

        else:
            print("{}{}{}".format(h.u(b'666c61677b'), h.c(self.code_val), "}"))

        if self.code_val == "":
            win2 = tk.Tk()
            win2.withdraw()

    def draw_header(self):
        self.grid()
        self.frame_header = tk.LabelFrame(self, bg='#FFFFFF', relief="flat")
        self.frame_header.grid(row=0, columnspan=1, sticky='E')
        self.header = tk.Label(self.frame_header, image=img_header, bg='#FFFFFF')
        self.header.grid(row=0, column=0, sticky='E')
        self.frame_header.place(x=50, y=40)
        self.main_text = tk.Label(self,
                                  text=h.u(b'4348414e4158204b45592047454e'),
                                  justify='center',
                                  fg='#003399',
                                  font=('Helvetica', 20),
                                  bg='#FFFFFF')
        self.main_text.place(x=210, y=80)
        self.sub_text = tk.Label(self,
                                 text="Plug in the right string and get the flag!",
                                 justify='left',
                                 font=('Helvetica', 10),
                                 bg='#FFFFFF')
        self.sub_text.place(x=210, y=110)

    def draw_text(self):
        self.lower_text = tk.Label(self,
                                   text="{}".format(
                                       h.u(b'546869732067656e657261746f722077696c6c2073706974206f75742061206b65792c20'
                                             b'627574206f6e6c7920696620796f7520656e74657220746865206d6167696320776f7264'
                                             b'2e0a496620796f75207374756d626c65642075706f6e20746869732070726f6772616d2c'
                                             b'20636c6f7365206974206e6f772e20596f752068617665206e6f20627573696e65737320'
                                             b'686572652e')
                                   ),
                                   justify='left',
                                   bg='#FFFFFF',
                                   fg='#000000'
                                   )
        self.lower_text.place(x=50, y=200)
        self.detail_text = tk.Label(self,
                                    justify='left',
                                    text="USER:\t{}@{}\nIP ADDR:\t{}\nTITLE:\t{}".format(
                                        gp.getuser(),
                                        socket.gethostname(),
                                        socket.gethostbyname(socket.gethostname()),
                                        ba.unhexlify('4348414e4158').decode('utf-8')
                                    ), bg='#FFFFFF')
        self.detail_text.place(x=50, y=245)


# FUNCTIONS
def showmsg():
    a = chr(var_lst[0])
    b = chr(var_lst[1]) * 2
    c = chr(var_lst[2])
    d = chr(var_lst[1])

    return "{}{}{}{}".format(a, b, c, d)

# MAINLOOP
if __name__ == '__main__':
    app = prgm(None)
    app.title(h.u(b'4348414e4158204b45592047454e'))
    app.configure(background='#FFFFFF')
    app.resizable(width=False, height=False)
    app.geometry('%dx%d+%d+%d' % (
        prgmWidth,
        prgmHeight,
        (app.winfo_screenwidth() / 2) - (prgmWidth / 2),
        (app.winfo_screenheight() / 2) - (prgmHeight / 2)))
    img_header = tk.PhotoImage(file='img/logoChanax.png')
    app.draw_header()
    app.draw_text()
    app.mainloop()
